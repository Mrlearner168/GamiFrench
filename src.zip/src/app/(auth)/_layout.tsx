import { useAuth } from '@/store/auth-context';
import { Stack, router } from 'expo-router';
import { useEffect } from 'react';

export default function GameLayout() {
  const { session, isLoading } = useAuth();

  useEffect(() => {
    // Only attempt to redirect after loading finishes and a session exists
    if (!isLoading && session) {
      // The timeout prevents race conditions between React's render cycle 
      // and Expo Router's navigation system.
      setTimeout(() => {
        router.replace('/(game)/home');
      }, 0);
    }
  }, [session, isLoading]);

  // It is perfectly safe to return null on the INITIAL mount while loading.
  // The crash only happens when unmounting a Stack that is already on screen.
  if (isLoading) return null;

  // The Stack remains mounted at all times when not loading, 
  // bypassing the frozen ref crash entirely.
  return <Stack screenOptions={{ headerShown: false }} />;
}