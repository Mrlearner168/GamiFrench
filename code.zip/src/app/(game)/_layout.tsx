import { useAuth } from '@/store/auth-context';
import { Stack, router } from 'expo-router';
import { useEffect } from 'react';

// 🚨 Extracted OUTSIDE the component to prevent React Native 
// from deep-freezing the object and crashing the navigation refs.
const STACK_OPTIONS = {
  headerShown: false,
  animation: 'slide_from_right' as const,
  contentStyle: { backgroundColor: '#F5F7FA' },
};

export default function GameLayout() {
  const { session, isLoading } = useAuth();

  useEffect(() => {
    console.log('[GameLayout] auth state', {
      isLoading,
      hasSession: Boolean(session),
    });

    // If still loading or we DO have a session, stay on the Game screens
    if (isLoading || session) return;

    // If loading is finished and there is NO session, kick them to login
    const redirectTimer = setTimeout(() => {
      console.log('[GameLayout] redirecting to login');
      router.replace('/(auth)/login');
    }, 0);

    return () => {
      console.log('[GameLayout] cancelling login redirect');
      clearTimeout(redirectTimer);
    };
  }, [session, isLoading]);

  console.log('[GameLayout] rendering Stack', { isLoading, hasSession: Boolean(session) });
  
  // Pass the external constant instead of an inline object
  return <Stack screenOptions={STACK_OPTIONS} />;
}